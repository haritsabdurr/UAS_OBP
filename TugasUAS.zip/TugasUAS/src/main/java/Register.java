import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Register extends JFrame {

    public static class config {
        private static Connection mysqlconfig;
        public static Connection configDB()throws SQLException {
            try {
                String url="jdbc:mysql://localhost:3306/javauas";
                String user="root"; //user database
                String pass=""; //password database
                DriverManager.registerDriver(new com.mysql.jdbc.Driver());
                mysqlconfig=DriverManager.getConnection(url, user, pass);
            } catch (Exception e) {
                System.err.println("koneksi gagal "+e.getMessage());
            }
            return mysqlconfig;
        }
    }

    public Register(){
        JFrame regis = new JFrame("Create Account ");
        regis.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        Container contenpane = regis.getContentPane();
        setLocationRelativeTo(null);

        SpringLayout layout = new SpringLayout();
        contenpane.setLayout (layout);

        Component label1 = new JLabel ( "Register Your Account" ) ;
        Component label2 = new JLabel ( "ID Customer :");
        Component label3 = new JLabel ( "Fullname :");
        Component label4 = new JLabel ( "Email :");
        Component label5 = new JLabel ( "Username :");
        Component label6 = new JLabel ( "Password :");

        final JTextField txtID = new JTextField ( 20) ;
        final JTextField txtname = new JTextField (20);
        final JTextField txtemail = new JTextField ( 20);
        final JTextField txtuname = new JTextField (20);
        final JTextField txtpass = new JTextField (20);

        final JButton btnA = new JButton("Register");

        btnA.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    if(txtID.getText().equals("") || txtname.getText().equals("") || txtemail.getText().equals("") || txtuname.getText().equals("") || txtpass.getText().equals("")){
                        JOptionPane.showMessageDialog(rootPane, "Please Input the Data!", "Pesan", JOptionPane.ERROR_MESSAGE);
                        txtID.requestFocus();
                    }else{
                        String sql = "INSERT INTO register  VALUES ('"+txtID.getText()+"','"+txtname.getText()+"','"+txtemail.getText()+"','"+txtuname.getText()+"','"+txtpass.getText()+"')";
                        java.sql.Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/javauas", "root", "");
                        java.sql.PreparedStatement pst=conn.prepareStatement(sql);
                        pst.execute();
                        JOptionPane.showMessageDialog(null, "Register Success");

                        regis.setVisible(false);
                    }
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(btnA, ex.getMessage());
                }
            }
        });

        contenpane.add ( label1 );
        contenpane.add ( label2 );
        contenpane.add ( label3 );
        contenpane.add ( label4 );
        contenpane.add ( label5 );
        contenpane.add ( label6 );

        contenpane.add ( txtID ) ;
        contenpane.add ( txtname ) ;
        contenpane.add ( txtemail ) ;
        contenpane.add ( txtuname ) ;
        contenpane.add ( txtpass ) ;

        contenpane.add( ( btnA )) ;

        layout.putConstraint(SpringLayout.WEST, label1,200,SpringLayout.WEST,contenpane);
        layout.putConstraint(SpringLayout.WEST, label2,20,SpringLayout.WEST,contenpane);
        layout.putConstraint(SpringLayout.NORTH, label2,50,SpringLayout.NORTH,contenpane);
        layout.putConstraint(SpringLayout.WEST, label3,20,SpringLayout.WEST,contenpane);
        layout.putConstraint(SpringLayout.NORTH, label3,80,SpringLayout.NORTH,contenpane);
        layout.putConstraint(SpringLayout.WEST, label4,20,SpringLayout.WEST,contenpane);
        layout.putConstraint(SpringLayout.NORTH, label4,110,SpringLayout.NORTH,contenpane);
        layout.putConstraint(SpringLayout.WEST, label5,20,SpringLayout.WEST,contenpane);
        layout.putConstraint(SpringLayout.NORTH, label5,140,SpringLayout.NORTH,contenpane);
        layout.putConstraint(SpringLayout.WEST, label6,20,SpringLayout.WEST,contenpane);
        layout.putConstraint(SpringLayout.NORTH, label6,170,SpringLayout.NORTH,contenpane);

        layout.putConstraint ( SpringLayout.NORTH, txtID, 50 , SpringLayout.NORTH, contenpane) ;
        layout.putConstraint ( SpringLayout.WEST, txtID, 40 , SpringLayout.EAST, label2 ) ;
        layout.putConstraint ( SpringLayout.NORTH, txtname, 80 , SpringLayout.NORTH, contenpane) ;
        layout.putConstraint ( SpringLayout.WEST, txtname, 40 , SpringLayout.EAST, label2 ) ;
        layout.putConstraint ( SpringLayout.NORTH, txtemail, 110 , SpringLayout.NORTH, contenpane) ;
        layout.putConstraint ( SpringLayout.WEST, txtemail, 40 , SpringLayout.EAST, label2 ) ;
        layout.putConstraint ( SpringLayout.NORTH, txtuname, 140 , SpringLayout.NORTH, contenpane) ;
        layout.putConstraint ( SpringLayout.WEST, txtuname, 40 , SpringLayout.EAST, label2 ) ;
        layout.putConstraint ( SpringLayout.NORTH, txtpass, 170 , SpringLayout.NORTH, contenpane) ;
        layout.putConstraint ( SpringLayout.WEST, txtpass, 40 , SpringLayout.EAST, label2 ) ;

        layout.putConstraint(SpringLayout.WEST, btnA,200,SpringLayout.WEST,contenpane);
        layout.putConstraint(SpringLayout.NORTH, btnA,200,SpringLayout.NORTH,contenpane);

        regis.setSize( 800, 500);
        regis.setVisible(true);
    }
}

