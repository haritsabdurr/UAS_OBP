import com.google.protobuf.Message;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Connection;

class CatalogEditPanel extends JPanel {

    static JTextField idp = new JTextField();
    static JTextField brand = new JTextField();
    static JTextField model = new JTextField();
    static JTextField jumlah = new JTextField();

    static Integer[] p = {
            1,
            2,
            3,
            4,
            5
    };
    static JComboBox stok = new JComboBox(p);

    CatalogEditPanel() {
        setLayout(new GridLayout(5, 2));

        add(new JLabel("ID Produk: "));
        add(idp);


        add(new JLabel("Brand: "));
        add(brand);


        add(new JLabel("Model: "));
        add(model);


        add(new JLabel("Quantity (Max. 5 Item per Cart) "));
        add(jumlah);

        Border etc = BorderFactory.createEtchedBorder(EtchedBorder.LOWERED);
        TitledBorder title = BorderFactory.createTitledBorder(etc, " Add to Cart Selection ");
        title.setTitleFont(title.getTitleFont().deriveFont(Font.BOLD));

        setBorder(BorderFactory.createCompoundBorder(new EmptyBorder(10, 10, 10, 10), title));
    }

    static class buttonadd implements ActionListener{

        public void actionPerformed(ActionEvent e) {
            try {
                String sql = "insert into employees(id,fullname,gender,position,salary) values(?,?,?,?,?)";
                Connection conn= DriverManager.getConnection("jdbc:mysql://localhost:3306/javauas", "root", "");
                PreparedStatement ps=conn.prepareStatement(sql);
                ps.setString(1,idp.getText());
                ps.setString(2,brand.getText());
                ps.setString(3, String.valueOf(jumlah.getText()));
                ps.setString(4, String.valueOf(stok.getSelectedItem()));
                ps.setInt(5, Integer.parseInt(model.getText()));
                ps.executeUpdate();
                ItemPanel.melihatdata();

                JOptionPane.showMessageDialog(null,"Data berhasil ditambah");

            } catch (Exception exception) {
                exception.printStackTrace();
            }
            formdikosongin();

        }

        private void formdikosongin(){
            idp.setText("");
            brand.setText("");
            model.setText("");
            jumlah.setText("");
            stok.setSelectedItem("");
        }
    }

    static class buttondelete implements ActionListener{
        public void actionPerformed(ActionEvent e) {
            try {
                String sql = "update produk set Stok = Stok - ? where id_produk= ? AND brand = ?";
                Connection conn= DriverManager.getConnection("jdbc:mysql://localhost:3306/javauas", "root", "");
                PreparedStatement ps=conn.prepareStatement(sql);
                ps.setString(2, idp.getText());
                ps.setString(3, brand.getText());
                ps.setInt(1, Integer.parseInt(jumlah.getText()));
                ps.executeUpdate();
                JOptionPane.showMessageDialog(null,"Product Succesfully Purchased");
                formdikosongin();
                ItemPanel.melihatdata();

                Invoice invoice = new Invoice();
                invoice.setVisible(true);

            } catch (Exception exception) {
                exception.printStackTrace();
                JOptionPane.showMessageDialog(null,"Please Input the Product", "Warning", JOptionPane.WARNING_MESSAGE);
            }
        }

        private void formdikosongin(){
            idp.setText("");

        }
    }
}










