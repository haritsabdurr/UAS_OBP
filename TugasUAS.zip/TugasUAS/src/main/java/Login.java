import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Login extends JFrame {

    public static class config {
        private static Connection mysqlconfig;
        public static Connection configDB()throws SQLException {
            try {
                String url="jdbc:mysql://localhost:3306/javauas";
                String user="root";
                String pass="";
                DriverManager.registerDriver(new com.mysql.jdbc.Driver());
                mysqlconfig=DriverManager.getConnection(url, user, pass);
            } catch (Exception e) {
                System.err.println("koneksi gagal "+e.getMessage());
            }
            return mysqlconfig;
        }
    }

    public Login(){
        final JFrame frame = new JFrame ( "Form Login" ) ;
        frame.setDefaultCloseOperation ( JFrame.EXIT_ON_CLOSE ) ;
        Container contentPane = frame.getContentPane () ;
        setLocationRelativeTo(null);

        SpringLayout layout = new SpringLayout () ;
        contentPane.setLayout ( layout ) ;

        Component label1 = new JLabel ( "Login" ) ;
        Component label2 = new JLabel ( "Username :" ) ;
        Component label3 = new JLabel ("Password :");

        JTextField txtbxa = new JTextField ( 20 ) ;
        JTextField txtbxb = new JTextField (20);

        JButton btnA = new JButton("Create Account ");
        JButton btnB = new JButton("Forget Password");
        JButton btnC = new JButton("Login");

        btnA.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Register regis = new Register();
                regis.setVisible(true);
            }
        });

        btnC.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    if(txtbxa.getText().equals("") || txtbxb.getText().equals("")){
                        JOptionPane.showMessageDialog(rootPane, "Incorrect Username or Password ", "Warning", JOptionPane.ERROR_MESSAGE);
                        txtbxa.requestFocus();
                    }else{
                        String sql = "SELECT * FROM register where username = '"+txtbxa.getText()+"' AND '"+txtbxb.getText()+"'";
                        java.sql.Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/javauas", "root", "");
                        java.sql.PreparedStatement pst=conn.prepareStatement(sql);
                        pst.execute();
                        JOptionPane.showMessageDialog(null, "Login Succes");

                        Catalog catalog = new Catalog();
                        catalog.setVisible(true);
                        frame.setVisible(false);

                    }
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(btnA, ex.getMessage());
                }

            }
        });

        contentPane.add (label1);
        contentPane.add (label2);
        contentPane.add (label3);

        contentPane.add (txtbxa);
        contentPane.add (txtbxb);

        contentPane.add (btnA);
        contentPane.add (btnB);
        contentPane.add (btnC);

        layout.putConstraint (SpringLayout.WEST, label1, 400 , SpringLayout.WEST, contentPane) ;
        layout.putConstraint (SpringLayout.NORTH, label1, 50 , SpringLayout.NORTH, contentPane) ;
        layout.putConstraint (SpringLayout.WEST, label2, 250 , SpringLayout.WEST, contentPane) ;
        layout.putConstraint (SpringLayout.NORTH, label2, 115 , SpringLayout.NORTH, contentPane) ;
        layout.putConstraint (SpringLayout.WEST, label3, 250 , SpringLayout.WEST, contentPane) ;
        layout.putConstraint (SpringLayout.NORTH, label3, 140 , SpringLayout.NORTH, contentPane) ;

        layout.putConstraint (SpringLayout.NORTH, txtbxa, 115 , SpringLayout.NORTH, contentPane) ;
        layout.putConstraint (SpringLayout.WEST, txtbxa, 20 , SpringLayout.EAST, label2) ;
        layout.putConstraint (SpringLayout.NORTH, txtbxb, 140 , SpringLayout.NORTH, contentPane) ;
        layout.putConstraint (SpringLayout.WEST, txtbxb, 20 , SpringLayout.EAST, label2) ;

        layout.putConstraint (SpringLayout.NORTH, btnA, 300 , SpringLayout.NORTH, contentPane) ;
        layout.putConstraint (SpringLayout.WEST, btnA, 220 , SpringLayout.WEST, contentPane) ;
        layout.putConstraint (SpringLayout.NORTH, btnB, 300 , SpringLayout.NORTH, contentPane) ;
        layout.putConstraint (SpringLayout.WEST, btnB, 120 , SpringLayout.EAST, btnA) ;

        layout.putConstraint (SpringLayout.WEST, btnC, 380 , SpringLayout.WEST, contentPane) ;
        layout.putConstraint (SpringLayout.NORTH, btnC, 250 , SpringLayout.NORTH, contentPane) ;

        frame.setSize (800 , 500) ;
        frame.setVisible (true) ;

    }

}
