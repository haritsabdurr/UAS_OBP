import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;
import java.awt.*;

public class DelivPanel extends JPanel {
    static JRadioButton rb = new JRadioButton();

    DelivPanel(){
        add(new JRadioButton("Express"));
        add(new JRadioButton("Regular"));


        Border etc = BorderFactory.createEtchedBorder(EtchedBorder.LOWERED);
        TitledBorder title = BorderFactory.createTitledBorder(etc, " Delivery Options ");
        title.setTitleFont(title.getTitleFont().deriveFont(Font.BOLD));

        setBorder(BorderFactory.createCompoundBorder(new EmptyBorder(10, 10, 10, 10), title));
    }
}
