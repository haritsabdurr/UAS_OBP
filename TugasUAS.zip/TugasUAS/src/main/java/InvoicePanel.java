import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;
import java.awt.*;

public class InvoicePanel extends JPanel {
    static JLabel brand = new JLabel();
    static JLabel model = new JLabel();
    static JLabel harga = new JLabel();
    static JLabel jumlah = new JLabel();

    public InvoicePanel(){

        setLayout(new GridLayout(5, 2));

        add(new JLabel("ID Produk: "));
        add(brand);


        add(new JLabel("Brand: "));
        add(model);


        add(new JLabel("Model: "));
        add(harga);


        add(new JLabel("Price: "));
        add(jumlah);

        Border etc = BorderFactory.createEtchedBorder(EtchedBorder.LOWERED);
        TitledBorder title = BorderFactory.createTitledBorder(etc, " Order Summary ");
        title.setTitleFont(title.getTitleFont().deriveFont(Font.BOLD));

        setBorder(BorderFactory.createCompoundBorder(new EmptyBorder(10, 10, 10, 10), title));
    }
}
