import javax.swing.*;

public class Invoice extends  JFrame{

    public Invoice(){
        setTitle("Invoice Order");
        setSize(800,500);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        setLayout(new BoxLayout(getContentPane(),BoxLayout.Y_AXIS));
        add(new InvoicePanel());
        add(new DelivPanel());
        add(new ButtonPanel2());

        setVisible(true);

    }
}