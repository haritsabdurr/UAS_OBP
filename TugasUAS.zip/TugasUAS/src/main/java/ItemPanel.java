import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

class ItemPanel extends JPanel {
    static DefaultTableModel tabelmodel;
    static  JTable table;

    ItemPanel() {
        tabelmodel=new DefaultTableModel();
        table = new JTable(tabelmodel);
        JScrollPane scrollPane = new JScrollPane(table);
        table.setFillsViewportHeight(true);
        table.setEnabled(false);
        this.melihatdata();

        setLayout(new GridLayout(1, 1));
        setBorder(new EmptyBorder(10, 10, 0, 12));

        add(scrollPane);
    }

    static void melihatdata (){
        try {
            tabelmodel= new DefaultTableModel();
            tabelmodel.addColumn("ID Produk");
            tabelmodel.addColumn("Brand");
            tabelmodel.addColumn("Model");
            tabelmodel.addColumn("Harga");
            tabelmodel.addColumn("Stok");
            PreparedStatement ps= DriverManager.getConnection("jdbc:mysql://localhost:3306/javauas", "root","").prepareStatement("select * from produk order by id_produk");
            ResultSet rs=ps.executeQuery();
            while (rs.next()){
                tabelmodel.addRow(
                        new Object[]{
                                rs.getString(1),
                                rs.getString(2),
                                rs.getString(3),
                                rs.getString(4),
                                rs.getString(5),
                        }
                );
            }

            table.setModel(tabelmodel);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }
}