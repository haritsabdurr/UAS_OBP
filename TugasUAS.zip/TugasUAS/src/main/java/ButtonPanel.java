import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

class ButtonPanel extends JPanel {

    JButton addbutton=new JButton("Add to Cart");
    JButton checkoutbutton=new JButton("Checkout");
    JButton closebutton=new JButton("Close");

    ButtonPanel(){
        setLayout(new GridLayout(1,4));
        add(addbutton);
        add(checkoutbutton);
        add(closebutton);
        addbutton.addActionListener(new CatalogEditPanel.buttonadd());
        checkoutbutton.addActionListener(new CatalogEditPanel.buttondelete());
        closebutton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
    }
}