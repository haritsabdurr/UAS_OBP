import javax.swing.*;

public class Catalog extends  JFrame{

    public Catalog(){
        setTitle("Catalog Form");
        setSize(800,500);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        setLayout(new BoxLayout(getContentPane(),BoxLayout.Y_AXIS));
        add(new ItemPanel());
        add(new CatalogEditPanel());
        add(new ButtonPanel());

        setVisible(true);

    }
}