import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

class ButtonPanel2 extends JPanel {

    JButton closebutton=new JButton("Close");

    ButtonPanel2(){
        setLayout(new GridLayout(1,4));
        add(closebutton);
        closebutton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
    }
}